<template>
    <h1>Texto do Componente</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>