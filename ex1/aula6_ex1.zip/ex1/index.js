import Vue from "vue/dist/vue.esm"

var app = new Vue({
    el: "#app",
    template: "<h1>Olá!</h1>"
});